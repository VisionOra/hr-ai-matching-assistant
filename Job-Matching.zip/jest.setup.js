import '@testing-library/jest-dom';

// Mock console.error to avoid noisy logs during tests
console.error = jest.fn(); 